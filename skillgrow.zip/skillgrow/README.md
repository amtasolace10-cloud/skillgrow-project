# SkillGrow (Flutter)
1. `flutter create skillgrow` (creates android/ios folders)
2. Replace its `lib/` and `pubspec.yaml` with the ones in this zip
3. `flutter pub get` then `flutter run`
